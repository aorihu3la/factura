import models.Contribuyente;
import models.Declaracion;
import models.EjercicioRN35;
import models.Periodo;

import java.util.ArrayList;
import java.util.List;

public class AppCoeficiente {
    public static void main(String[] args) {
        // creando datos
        Contribuyente ruc01 = new Contribuyente("20131312955", "Sunat","030301");
        Declaracion dj710 = new Declaracion("0710","202313",0.014);

        guardarCoeficiente(ruc01, dj710);


    }

    public static void guardarCoeficiente(Contribuyente ruc, Declaracion dj){
        List<Periodo> periodos4a = new ArrayList<>();
        List<Periodo> periodosMas1 = new ArrayList<>();
        String tipoDj = dj.getCodFor();
        int ej4a = Integer.parseInt(dj.getPerDoc().substring(0,4))+1;
        //System.out.println(tipoDj + " " + ej4a);

        // generando periodos AAAA
        for(int i =3; i<13; i++){
           String mes = String.format("%02d", i);
            String per = String.valueOf(ej4a) + mes;

            periodos4a.add(new Periodo(String.valueOf(ej4a), per, dj.getCoeficiente()));
        }

        for(int i =1; i<3; i++){
            String mes = String.format("%02d", i);
            String per = String.valueOf(ej4a+1) + mes;
            periodosMas1.add(new Periodo(String.valueOf(ej4a+1), per, dj.getCoeficiente()));
        }


        periodos4a.forEach(System.out::println);
        System.out.println(" \n");
        periodosMas1.forEach(System.out::println);


    }
}
