package models;

public class Coeficiente {

}
