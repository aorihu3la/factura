package models;

public class Periodo {
    private String ejercicio;
    private String codPeriodo;
    private Double coeficiente;

    public Periodo() {
    }

    public Periodo(String ejercicio, String codPeriodo, Double coeficiente) {
        this.ejercicio = ejercicio;
        this.codPeriodo = codPeriodo;
        this.coeficiente = coeficiente;
    }

    public String getCodPeriodo() {
        return codPeriodo;
    }

    public void setCodPeriodo(String codPeriodo) {
        this.codPeriodo = codPeriodo;
    }

    public Double getCoeficiente() {
        return coeficiente;
    }

    public void setCoeficiente(Double coeficiente) {
        this.coeficiente = coeficiente;
    }


    @Override
    public String toString() {
        return ejercicio + " " + codPeriodo + " " + coeficiente;
    }
}
