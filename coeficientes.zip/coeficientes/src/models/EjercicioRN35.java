package models;

import java.util.List;

public class EjercicioRN35 {
    private List<Periodo> periodos4a;
    private List<Periodo> periodosMas1;
}


