package models;

public class Declaracion {
    private String codFor;
    private String numFor;
    private String perDoc;
    private Double coeficiente;


    public Declaracion() {
    }

    public Declaracion(String codFor, String perDoc, Double coeficiente) {
        this.codFor = codFor;
        this.perDoc = perDoc;
        this.coeficiente = coeficiente;
    }

    public String getCodFor() {
        return codFor;
    }

    public void setCodFor(String codFor) {
        this.codFor = codFor;
    }

    public String getNumFor() {
        return numFor;
    }

    public void setNumFor(String numFor) {
        this.numFor = numFor;
    }

    public String getPerDoc() {
        return perDoc;
    }

    public void setPerDoc(String perDoc) {
        this.perDoc = perDoc;
    }

    public Double getCoeficiente() {
        return coeficiente;
    }

    public void setCoeficiente(Double coeficiente) {
        this.coeficiente = coeficiente;
    }

    @Override
    public String toString() {
        return codFor + " " + perDoc + " " + coeficiente;
    }
}
