package models;

public class Contribuyente {
    private String numRuc;
    private String nombre;
    private String afectacion;


    public Contribuyente() {
    }

    public Contribuyente(String numRuc, String nombre, String afectacion) {
        this.numRuc = numRuc;
        this.nombre = nombre;
        this.afectacion = afectacion;
    }

    public String getNumRuc() {
        return numRuc;
    }

    public void setNumRuc(String numRuc) {
        this.numRuc = numRuc;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAfectacion() {
        return afectacion;
    }

    public void setAfectacion(String afectacion) {
        this.afectacion = afectacion;
    }

    @Override
    public String toString() {
        return "Contribuyente " + numRuc + " " + nombre + " " + afectacion + " ";
    }
}
