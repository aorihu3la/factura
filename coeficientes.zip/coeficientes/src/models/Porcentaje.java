package models;

public class Porcentaje {
}
